let clienteController = new ClienteController();
clienteController.listar();
const cl1 = new Cliente('Marcus', 444);
const ce1 = new ClienteEspecial('Beatriz', 222);
console.log('Cliente: ' + cl1.cpf);
ce1.pesquisarClientePeloCpf(222);
console.log('Cliente Especial: ' + ce1.cpf);