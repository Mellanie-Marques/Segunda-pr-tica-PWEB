class ClienteEspecial extends Cliente {
    constructor(nome, cpf) {
        super(nome, cpf);
        super(cliente = []);
    }
    
}