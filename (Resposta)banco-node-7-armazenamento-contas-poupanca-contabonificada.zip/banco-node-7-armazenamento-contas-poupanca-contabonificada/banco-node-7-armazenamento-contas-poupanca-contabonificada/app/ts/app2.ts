let clienteController = new ClienteController();

contaController.listar();

const cl1 = new Cliente('Marcus', 444);
const ce1 = new ClienteEspecial('Beatriz', 222);

console.log('Cliente: ' + cl1.cpf);

