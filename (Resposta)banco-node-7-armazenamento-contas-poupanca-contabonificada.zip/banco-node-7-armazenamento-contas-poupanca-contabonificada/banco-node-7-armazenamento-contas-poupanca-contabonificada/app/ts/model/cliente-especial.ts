class ClienteEspecial extends Cliente{

    constructor(nome: string, cpf: number) {
        super(nome, cpf);
    }

}